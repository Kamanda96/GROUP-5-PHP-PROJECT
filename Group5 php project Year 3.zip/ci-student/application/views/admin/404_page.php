<br>
<div class="_404-page" style="min-height: 500px">
	<div class="section-title"><i class="far fa-file"></i> Page not found</div>
	<div class="error-type">404</div>
	<div class="_404text">Sorry! The page you are looking for, doesn't exist or implemented yet.</div>
</div>