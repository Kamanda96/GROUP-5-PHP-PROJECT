<div class="welcome-area">
    <div class="owl-carousel slider-content">
        <div class="single-slider-item slider-bg-1">
            <div class="slider-inner">
                <div class="container">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="slide-text">
                                <h2>Building a civilization of love</h2>
                                <p>Even the greatest were beginners. <br> Don’t be afraid to take that first step!!</p>

                                <a href="" class="boxed-btn">learn more <i class="fas fa-arrow-right"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="single-slider-item slider-bg-2">
            <div class="slider-inner">
                <div class="container">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="slide-text">
                                <h2>Wide range of degrees & programs</h2>
                                <p>Excellence is not a skill. It is an attitude!<br> - Ralph Marston</p>

                                <a href="" class="boxed-btn">learn more <i class="fas fa-arrow-right"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>