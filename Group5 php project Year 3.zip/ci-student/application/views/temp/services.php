<div class="container">
    <div class="section-title">Our services</div>
    <div class="row">
        <div class="col-lg-4">
            <a href="#" class="single-services">
               <i class="fas fa-school"></i>
                <h4>Most Qualified Lecturers</h4>
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Cupiditate maiores dolores, rem. Adipisci dolor molestiae obcaecati ratione dolores officia illum!</p>
            </a>
        </div>
        <div class="col-lg-4">
            <a href="#" class="single-services">
                <i class="fas fa-tractor"></i>
                <h4>Extra care for week students</h4>
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Cupiditate maiores dolores, rem. Adipisci dolor molestiae obcaecati ratione dolores officia illum!</p>
            </a>
        </div>
        <div class="col-lg-4">
            <a href="#" class="single-services">
                <i class="fas fa-medal"></i>
                <h4>Regular Model test</h4>
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Cupiditate maiores dolores, rem. Adipisci dolor molestiae obcaecati ratione dolores officia illum!</p>
            </a>
        </div>
    </div>
</div>